# Polityka i licznik API (Node.js 20+, CommonJS, bez zależności)
`const { readApiPolicy, decideStart, recordUsage } = require('./server/index.cjs');`
`config = readApiPolicy(markdownLubObiektPolityki)` czyta pierwszą sekcję `api` bloku `json envi-agent-policy`.
Brak lub błędne ustawienia wyłączają API z polskim powodem; kwoty i ceny są nieujemnymi liczbami USD.
System dostarcza `store.append(entry)` oraz `store.list({start,end})` (obie metody mogą być asynchroniczne).
`list` zwraca pozycje z przedziału `[start,end)`: `time` w ISO UTC, `kind`, `user`, `model`, `bucket`, `tokens`, `cost_usd`.
`await decideStart(config, store, {kind,user,model,bucket,estimated_cost_usd,now})` zwraca `decision`: `allowed`, `denied` lub `subscription`, z `reason` dla dwóch ostatnich.
`bucket` to `pomoc` albo `analiza`; Pomoc wymaga własnego wyłącznika i listy osób, ale zużywa też wspólny budżet.
Po całym przebiegu `await recordUsage(config, store, {kind,user,model,bucket,usage,now})` zapisuje sumaryczny koszt; błąd zapisu przerywa wywołanie.
`usage` wymaga `input_tokens` i `output_tokens`; dwa pola cache są opcjonalne (domyślnie 0); jeden przebieg Pomocy (jedna pozycja licznika) to jedno pytanie.
Okresy i dni są w UTC, od północy dnia `billing_day` (w krótszym miesiącu ostatni dzień), bez przenoszenia salda.
Cennik ma jedną stawkę `cache_write`; system musi dopasować ją do używanego czasu przechowywania cache; nie ma mnożników Batch ani innych trybów.
System serializuje kontrolę startu i przebiegi we wspólnej puli; szacunek musi ograniczać rzeczywisty wydatek. Licznik nie rezerwuje środków.
`createMemoryStore()` służy tylko testom; biblioteka nie czyta środowiska i nie tworzy klienta API. `npm run test:server` uruchamia testy.

System pobiera kanon przez `readApiPolicy(await readCanonFile({token, path}))`; token tylko do odczytu pochodzi z sekretu serwera.
Błąd odczytu kanonu system musi potraktować jako wyłączone API.
`readCanonFile` obsługuje dowolny plik, opcjonalne `repo` i `ref` oraz wstrzyknięty `fetch`; odczyt jest bez cache (limit 5000/h na token).
`runOnce({client, config, store, kind, user, bucket, model, effort, system, messages, tools, cache = false, max_turns, max_tokens, estimated_cost_per_call_usd, now})` prowadzi przebieg; klient ma metodę `messages.create`.
`cache: true` dodaje znaczniki `ephemeral` na bloku instrukcji i ostatnim bloku ostatniej wiadomości wyłącznie w kopii wysyłanej do modelu; Pomoc włącza cache, analizy zachowują domyślne wyłączenie.
Narzędzia systemu mają `{name, description, input_schema, run(input)}`; wynik `run` to tekst lub wartość serializowana do JSON, a błąd wraca jako `is_error`.
Przed każdym wywołaniem kontrolowany jest budżet z kosztem bieżącego przebiegu; `finally` zapisuje jedną pozycję za wszystkie odebrane odpowiedzi, także przy błędzie.
Przed pierwszym i każdym kolejnym wywołaniem szacunek wynosi maksimum ze stałej gospodarza `estimated_cost_per_call_usd` (zapas na ukryty narzut) i kosztu bajtów UTF-8 `JSON.stringify({system, messages, tools})` po wyższej stawce wejścia/zapisu cache, plus `max_tokens` po stawce wyjścia. `messages` obejmuje całą dotychczasową historię, a `tools` zawiera definicje bez funkcji `run`.
Wynik zawiera `decision`, opcjonalne `reason` i `stop_reason`, ostatnie `content`, `text` ostatniego kroku (jeśli pusty, ostatni niepusty tekst z wcześniejszych kroków; bloki tekstu w kroku łączone nową linią), sumę `usage`, `cost_usd` i `turns`; błędy klienta są zastępowane polskim komunikatem.
`compareReadThenReason({client, config, store, user, kind, documents, question, reasoner, reader, max_tokens, estimated_cost_per_call_usd, now})` wykonuje A, potem dwa etapy B, każdy jako osobny przebieg w puli `analiza`.
`documents` to tablica `{title,text}`, `reader` i `reasoner` wymagają `{model,effort}`; wynik podaje odpowiedzi, wyciąg i koszty, a nieukończony etap zatrzymuje dalsze etapy. Błędy merytoryczne ocenia człowiek.
System dobiera szacunek do każdego możliwego wywołania i serializuje przebiegi; brak automatycznego modelu zapasowego, obsługi narzędzi serwerowych i dodatkowych trybów cenowych.

## Pomoc
`const { runPomoc } = require('@envi/agent-server/pomoc');`
`await runPomoc({client, config, store, user, model, effort, system_name, system_version, history, question, screen, markers, code_dir, data_tools, max_turns, max_tokens, estimated_cost_per_call_usd, now})` obsługuje jedno pytanie w puli `pomoc` (rodzaj `HELP`).
Model i effort dostarcza system z polityki; `now` jest opcjonalną funkcją zegara jak w `runOnce`.
`history` (domyślnie `[]`) zawiera tylko `{role: 'user'|'assistant', content: tekst}`: do 40 wpisów, 8000 znaków na wpis, 40000 łącznie; pytanie do 8000 znaków.
`screen` to `{name, path}` (po 1000 znaków); nazwa i wersja systemu do 160 znaków.
`markers` (domyślnie `[]`) to do 200 unikalnych `{id, label}` (160/1000 znaków); model może zaznaczyć tylko te identyfikatory.
`code_dir` wskazuje przygotowaną przez gospodarza, niezmienną kopię kodu wdrożonej wersji, bez sekretów, danych testowych i dowiązań twardych poza kopię.
Wbudowane narzędzia: `code_list({prefix?})`, `code_search({text, prefix?, limit?})` (tekst dosłowny, do 40 trafień), `code_read({path, line, lines?})` (od 1, domyślnie 20, do 80 linii wokół wskazanej), `highlight({id})` (tylko przy niepustym katalogu znaczników), `draft_ticket({title, description})` (200/8000 znaków, niczego nie wysyła).
Ścieżki i prefiksy są względne, z separatorem `/`, bez pustych segmentów i segmentów zaczynających się kropką; pusty prefiks oznacza całą kopię, końcowy `/` jest dozwolony dla prefiksu. Lista i wyszukiwanie pomijają pliki binarne, większe niż 1 MB i niemożliwe do odczytania. Dowiązania nie są listowane ani przeszukiwane; odczyt sprawdza rzeczywistą ścieżkę wewnątrz kopii. Tekst linii trafienia jest ograniczony do 300 znaków.
`data_tools` (domyślnie `[]`) to `{name, description, input_schema, run}`: wyłącznie zapytania odczytu już związane przez gospodarza z zalogowanym użytkownikiem i jego uprawnieniami. Nazwy muszą być unikalne i nie mogą kolidować z wbudowanymi. Każdy wynik narzędzia ma limit 12000 znaków (nadmiar jest przycinany ze znacznikiem `[wynik przycięty]`). Błędy walidacji narzędzi Pomocy wracają do modelu z komunikatem `Błąd: …` i `is_error`; szczegóły błędów systemu plików i adapterów danych pozostają ukryte.
Wynik: `decision`, opcjonalne `reason` i `stop_reason` jak w `runOnce`, `text` ukończonej odpowiedzi (inaczej pusty), `based_on` tylko przy odpowiedzi (`Na podstawie <system> <wersja>`), `markers` (identyfikatory), `ticket_draft` (`{title, description}` lub `null`), `cost_usd`, `conversation`.
`conversation` zawiera wcześniejsze tekstowe wymiany, pytanie tylko po faktycznym wywołaniu modelu i ukończoną odpowiedź, bez wyników i wywołań narzędzi ani roboczego rozumowania. System przechowuje rozmowę, ogranicza historię kolejnego pytania i odpowiada za retencję.

## Paczka serwerowa
`server/package.json` udostępnia `@envi/agent-server` dla Node.js 20+, bez zależności. Główny eksport to polityka/licznik i `runOnce`; podścieżka `/pomoc` udostępnia `runPomoc`.
`npm pack` w `server/` pakuje tylko `index.cjs`, `pomoc.cjs`, README i manifest; testy uruchamia się z korzenia repozytorium. Program pracownika w korzeniu nadal wymaga Node.js 22+.

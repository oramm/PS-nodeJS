'use strict';

const isObject = value => value !== null && typeof value === 'object' &&
  [Object.prototype, null].includes(Object.getPrototypeOf(value));
const money = value => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const identifier = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._@:-]{0,159}$/.test(value);
const list = value => Array.isArray(value) && Array.from(value).every(identifier) && new Set(value).size === value.length;
const shape = (value, keys) => isObject(value) && Object.keys(value).length === keys.length &&
  keys.every(key => Object.hasOwn(value, key));
const priceKeys = ['input', 'output', 'cache_write', 'cache_read'];
const usageKeys = ['input_tokens', 'output_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens'];
const off = reason => ({ enabled: false, reason });

function readApiPolicy(source) {
  try {
    if (typeof source === 'string') {
      const block = /^```json envi-agent-policy[ \t]*\r?\n([\s\S]*?)^```[ \t]*\r?$/m.exec(source);
      if (!block) return off('API jest wyłączone: brak bloku polityki firmy.');
      source = JSON.parse(block[1]);
    }
    if (!isObject(source)) throw new Error();
    if (!Object.hasOwn(source, 'api')) return off('API jest wyłączone: brak ustawień API.');
    const api = source.api;
    if (!shape(api, ['enabled', 'billing_day', 'monthly_budget_usd', 'kinds', 'users', 'pomoc', 'prices_usd_per_mtok']) ||
        typeof api.enabled !== 'boolean' || !Number.isInteger(api.billing_day) || api.billing_day < 1 || api.billing_day > 31 ||
        !money(api.monthly_budget_usd) || !list(api.kinds) || !list(api.users) ||
        !shape(api.pomoc, ['enabled', 'monthly_budget_usd', 'users', 'daily_questions_per_user']) ||
        typeof api.pomoc.enabled !== 'boolean' || !money(api.pomoc.monthly_budget_usd) || !list(api.pomoc.users) ||
        !Number.isSafeInteger(api.pomoc.daily_questions_per_user) || api.pomoc.daily_questions_per_user < 0 ||
        !isObject(api.prices_usd_per_mtok)) throw new Error();
    for (const [model, price] of Object.entries(api.prices_usd_per_mtok)) {
      if (!identifier(model) || !shape(price, priceKeys) || !priceKeys.every(key => money(price[key]))) throw new Error();
    }
    return structuredClone(api);
  } catch {
    return off('API jest wyłączone: ustawienia API w polityce firmy są niepoprawne.');
  }
}

function date(value) {
  if (!(value instanceof Date) && typeof value !== 'string') throw new Error('Niepoprawna data.');
  const result = new Date(value);
  if (!Number.isFinite(result.getTime())) throw new Error('Niepoprawna data.');
  return result;
}

function billingPeriod(now, billingDay) {
  const current = date(now);
  if (!Number.isInteger(billingDay) || billingDay < 1 || billingDay > 31) throw new Error('Niepoprawny dzień rozliczenia.');
  const boundary = month => {
    const lastDay = new Date(Date.UTC(current.getUTCFullYear(), month + 1, 0)).getUTCDate();
    return new Date(Date.UTC(current.getUTCFullYear(), month, Math.min(billingDay, lastDay)));
  };
  const month = current.getUTCMonth();
  const startMonth = current < boundary(month) ? month - 1 : month;
  return { start: boundary(startMonth).toISOString(), end: boundary(startMonth + 1).toISOString() };
}

function validateContext({ kind, user, model, bucket }) {
  if (![kind, user, model].every(identifier) || !['pomoc', 'analiza'].includes(bucket)) throw new Error('Niepoprawne dane przebiegu API.');
}

function calculateCost(usage, price) {
  if (!shape(price, priceKeys) || !priceKeys.every(key => money(price[key])) || !isObject(usage)) {
    throw new Error('Niepoprawny cennik lub zużycie tokenów.');
  }
  const tokens = Object.fromEntries(usageKeys.map((key, i) => [key, i < 2 ? usage[key] : usage[key] ?? 0]));
  if (!Object.values(tokens).every(value => Number.isSafeInteger(value) && value >= 0)) throw new Error('Niepoprawne zużycie tokenów.');
  const cost = usageKeys.reduce((sum, key, i) => sum + tokens[key] * price[priceKeys[i]] / 1e6, 0);
  if (!money(cost)) throw new Error('Nie można obliczyć kosztu API.');
  return { tokens, cost_usd: cost };
}

async function recordUsage(config, store, { kind, user, model, bucket, usage, now }) {
  validateContext({ kind, user, model, bucket });
  const api = readApiPolicy({ api: config });
  if (!api.prices_usd_per_mtok || !Object.hasOwn(api.prices_usd_per_mtok, model)) throw new Error('Brak ceny modelu w polityce firmy.');
  const entry = { time: date(now).toISOString(), kind, user, model, bucket,
    ...calculateCost(usage, api.prices_usd_per_mtok[model]) };
  try { await store.append(entry); }
  catch { throw new Error('Nie udało się zapisać kosztu API.'); }
  return entry;
}

const deny = reason => ({ decision: 'denied', reason });
const usd = value => value.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2, useGrouping: false });
function budgetReason(label, remaining, budget, end) {
  const renewal = new Intl.DateTimeFormat('pl-PL', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(date(end));
  return `${label} na ten okres rozliczeniowy nie wystarcza (zostało ${usd(remaining)} USD z ${usd(budget)} USD). Odnowienie ${renewal}.`;
}

// shortcut: only recorded costs are counted; add atomic reservations when integrating concurrent runs.
async function decideStart(config, store, request) {
  // readApiPolicy result for a disabled policy has only {enabled, reason}; keep its reason instead of re-validating.
  const api = config?.enabled === false ? config : readApiPolicy({ api: config });
  if (!api.enabled) return deny(api.reason || 'API jest wyłączone przez właściciela.');
  try {
    validateContext(request);
    if (!money(request.estimated_cost_usd)) throw new Error();
    const now = date(request.now);
    const period = billingPeriod(now, api.billing_day);
    const pomoc = request.bucket === 'pomoc';
    // Pomoc runs only on the server; it has no subscription path, so its kind needs no entry in kinds.
    if (!pomoc && !api.kinds.includes(request.kind)) return { decision: 'subscription', reason: 'Ten rodzaj działania korzysta z abonamentu pracownika.' };
    if (pomoc && !api.pomoc.enabled) return deny('Pomoc przez API jest wyłączona przez właściciela.');
    if (!(pomoc ? api.pomoc.users : api.users).includes(request.user)) return deny('Nie masz uprawnień do uruchomienia tego działania przez API.');
    if (!Object.hasOwn(api.prices_usd_per_mtok, request.model)) return deny('Brak ceny wybranego modelu w polityce firmy. Zgłoś to administratorowi.');
    let entries;
    try {
      entries = await store.list(period);
      if (!Array.isArray(entries)) throw new Error();
      for (const entry of entries) {
        if (!isObject(entry) || !money(entry.cost_usd) || !['pomoc', 'analiza'].includes(entry.bucket) || !identifier(entry.user)) throw new Error();
        if (entry.time !== date(entry.time).toISOString()) throw new Error();
      }
      entries = entries.filter(entry => entry.time >= period.start && entry.time < period.end);
    } catch { return deny('Nie można odczytać licznika kosztu API. Spróbuj ponownie później.'); }
    const total = entries.reduce((sum, entry) => sum + entry.cost_usd, 0);
    const remaining = Math.max(0, api.monthly_budget_usd - total);
    if (total >= api.monthly_budget_usd || request.estimated_cost_usd > remaining) {
      return deny(budgetReason('Budżet API', remaining, api.monthly_budget_usd, period.end));
    }
    if (pomoc) {
      const spent = entries.filter(entry => entry.bucket === 'pomoc').reduce((sum, entry) => sum + entry.cost_usd, 0);
      const left = Math.max(0, api.pomoc.monthly_budget_usd - spent);
      if (spent >= api.pomoc.monthly_budget_usd || request.estimated_cost_usd > left) {
        return deny(budgetReason('Limit Pomocy', left, api.pomoc.monthly_budget_usd, period.end));
      }
      const today = now.toISOString().slice(0, 10);
      const questions = entries.filter(entry => entry.bucket === 'pomoc' && entry.user === request.user && date(entry.time).toISOString().startsWith(today)).length;
      if (questions >= api.pomoc.daily_questions_per_user) return deny('Dzienny limit pytań Pomocy został wyczerpany. Spróbuj ponownie jutro.');
    }
    return { decision: 'allowed' };
  } catch { return deny('Niepoprawne dane uruchomienia API. Zgłoś to administratorowi.'); }
}

function createMemoryStore() {
  const entries = [];
  return {
    async append(entry) { entries.push(structuredClone(entry)); },
    async list({ start, end }) { return structuredClone(entries.filter(entry => entry.time >= start && entry.time < end)); },
  };
}

async function readCanonFile({ token, path, fetch = globalThis.fetch, repo = 'envi-konsulting/ENVI.SB', ref = 'main' }) {
  try {
    if (typeof token !== 'string' || !token || typeof path !== 'string' || !path ||
        !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo) || typeof ref !== 'string' || !ref ||
        path.split('/').some(segment => !segment || segment === '.' || segment === '..')) throw new Error();
    const encodedPath = path.split('/').map(encodeURIComponent).join('/');
    // shortcut: brak cache (limit GitHuba 5000/h na token), dodać cache przy zbliżeniu do limitu.
    const response = await fetch(`https://api.github.com/repos/${repo}/contents/${encodedPath}?ref=${encodeURIComponent(ref)}`, {
      method: 'GET', redirect: 'error', headers: {
        Accept: 'application/vnd.github.raw', Authorization: `Bearer ${token}`,
        'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'envi-agent-server',
      },
    });
    if (response.status !== 200) throw new Error();
    return await response.text();
  } catch { throw new Error('Nie udało się odczytać pliku kanonu z GitHuba.'); }
}

class ToolValidationError extends Error {}

function estimateCallCost(system, messages, tools, max_tokens, price, overhead) {
  if (!price) return overhead; // decideStart zachowuje powód odmowy przy braku cennika.
  const bytes = Buffer.byteLength(JSON.stringify({ system, messages, tools }), 'utf8');
  return Math.max(overhead, (bytes * Math.max(price.input, price.cache_write) + max_tokens * price.output) / 1e6);
}

async function runOnce({ client, config, store, kind, user, bucket, model, effort, system, messages,
  tools = [], cache = false, max_turns, max_tokens, estimated_cost_per_call_usd, now = () => new Date() }) {
  if (!client || typeof client.messages?.create !== 'function' || typeof effort !== 'string' || !effort ||
      !Array.isArray(messages) || !Array.isArray(tools) ||
      tools.some(tool => !isObject(tool) || !identifier(tool.name) || typeof tool.description !== 'string' ||
        !isObject(tool.input_schema) || typeof tool.run !== 'function') ||
      new Set(tools.map(tool => tool.name)).size !== tools.length ||
      !Number.isSafeInteger(max_turns) || max_turns < 1 || !Number.isSafeInteger(max_tokens) || max_tokens < 1 ||
      !money(estimated_cost_per_call_usd) || typeof cache !== 'boolean' || typeof now !== 'function') {
    throw new Error('Niepoprawne parametry przebiegu API.');
  }
  const history = structuredClone(messages);
  const usage = Object.fromEntries(usageKeys.map(key => [key, 0]));
  const apiTools = tools.map(({ name, description, input_schema }) => ({ name, description, input_schema }));
  let content = [], text = '', turns = 0, cost_usd = 0;
  let decision, reason, stop_reason;
  const context = { kind, user, bucket, model };
  try {
    while (turns < max_turns) {
      ({ decision, reason } = await decideStart(config, store, { ...context, now: now(),
        estimated_cost_usd: cost_usd + estimateCallCost(system, history, apiTools, max_tokens,
          config?.prices_usd_per_mtok?.[model], estimated_cost_per_call_usd) }));
      if (decision !== 'allowed') break;
      let response;
      try {
        const apiMessages = structuredClone(history);
        if (cache && apiMessages.length) {
          const last = apiMessages.at(-1);
          if (typeof last.content === 'string') last.content = [{ type: 'text', text: last.content }];
          if (last.content.length) last.content.at(-1).cache_control = { type: 'ephemeral' };
        }
        response = await client.messages.create({ model, max_tokens,
          system: cache ? [{ type: 'text', text: system, cache_control: { type: 'ephemeral' } }] : system,
          messages: apiMessages,
          ...(tools.length ? { tools: apiTools } : {}),
          output_config: { effort } });
      } catch { throw new Error('Nie udało się uzyskać odpowiedzi z API modelu.'); }
      turns++;
      let measured;
      try { measured = calculateCost(response?.usage, config.prices_usd_per_mtok[model]); }
      catch { throw new Error('API zwróciło niepoprawne zużycie tokenów.'); }
      for (const key of usageKeys) usage[key] += measured.tokens[key];
      cost_usd = calculateCost(usage, config.prices_usd_per_mtok[model]).cost_usd;
      if (response.model !== model) throw new Error('API zwróciło inny model niż wybrany w polityce firmy.');
      if (response.usage.server_tool_use && Object.values(response.usage.server_tool_use).some(count => count !== 0)) {
        throw new Error('API użyło narzędzia serwerowego, którego kosztu nie obsługujemy.');
      }
      if (!Array.isArray(response.content)) throw new Error('API zwróciło niepoprawną treść odpowiedzi.');
      content = response.content;
      text = content.filter(block => block.type === 'text').map(block => block.text).join('\n') || text;
      stop_reason = response.stop_reason;
      if (stop_reason !== 'tool_use') {
        if (stop_reason !== 'end_turn') {
          const reasons = { refusal: 'Model odmówił odpowiedzi.', max_tokens: 'Osiągnięto limit tokenów odpowiedzi.',
            pause_turn: 'Model wstrzymał przebieg.' };
          reason = Object.hasOwn(reasons, stop_reason) ? reasons[stop_reason] : 'Model zakończył przebieg z nieznanym powodem.';
        }
        break;
      }
      if (turns === max_turns) {
        stop_reason = 'max_turns';
        reason = 'Osiągnięto limit wywołań modelu w przebiegu.';
        break;
      }
      const results = [];
      for (const block of content.filter(block => block.type === 'tool_use')) {
        const tool = tools.find(tool => tool.name === block.name);
        let result;
        try {
          if (!tool) throw new Error();
          const value = await tool.run(structuredClone(block.input));
          const text = typeof value === 'string' ? value : JSON.stringify(value);
          result = text ? { content: text } : {};
        } catch (error) {
          result = { content: error instanceof ToolValidationError ? `Błąd: ${error.message}` :
            tool ? 'Nie udało się wykonać narzędzia.' : 'Nieznane narzędzie.', is_error: true };
        }
        results.push({ type: 'tool_result', tool_use_id: block.id, ...result });
      }
      if (!results.length) throw new Error('API zażądało narzędzi bez bloków wywołań.');
      history.push({ role: 'assistant', content }, { role: 'user', content: results });
    }
    return { decision, ...(reason ? { reason } : {}), ...(stop_reason ? { stop_reason } : {}),
      content, text,
      usage, cost_usd, turns };
  } finally {
    if (turns) await recordUsage(config, store, { ...context, usage, now: now() });
  }
}

const wholeInstruction = 'Odpowiedz na pytanie na podstawie dokumentów. Uzasadnij wnioski cytatami ze wskazaniem tytułu dokumentu. Jeśli brakuje danych, powiedz to wprost.';
const readInstruction = 'Wyodrębnij tylko fakty potrzebne do odpowiedzi na pytanie. Każdy fakt poprzyj dosłownym cytatem i tytułem dokumentu. Zaznacz braki danych i sprzeczności, nie formułuj końcowej odpowiedzi.';
const reasonInstruction = 'Odpowiedz na pytanie wyłącznie na podstawie wyciągu faktów. Uzasadnij wnioski cytatami i wskazaniem dokumentów z wyciągu. Jeśli wyciąg nie wystarcza, powiedz to wprost.';

async function compareReadThenReason({ client, config, store, user, kind, documents, question, reasoner, reader,
  max_tokens, estimated_cost_per_call_usd, now }) {
  if (!Array.isArray(documents) || documents.some(doc => !isObject(doc) || typeof doc.title !== 'string' || typeof doc.text !== 'string') ||
      typeof question !== 'string' || ![reader, reasoner].every(stage => isObject(stage) && identifier(stage.model) &&
        typeof stage.effort === 'string' && stage.effort)) throw new Error('Niepoprawne dane porównania modeli.');
  const source = documents.map(doc => `Dokument: ${doc.title}\n${doc.text}`).join('\n\n');
  const common = { client, config, store, user, kind, bucket: 'analiza', max_tokens,
    estimated_cost_per_call_usd, now, max_turns: 1 };
  const run = (stage, system, input) => runOnce({ ...common, model: stage.model, effort: stage.effort, system,
    messages: [{ role: 'user', content: `${input}\n\nPytanie: ${question}` }] });
  const summary = ({ text, cost_usd, usage, decision, reason, stop_reason }) =>
    ({ text, cost_usd, usage, decision, ...(reason ? { reason } : {}), ...(stop_reason ? { stop_reason } : {}) });
  const complete = result => result.decision === 'allowed' && result.stop_reason === 'end_turn';
  const a = await run(reasoner, wholeInstruction, source);
  const b = { extract: '', text: '', cost_usd: 0, usage: { reader: null, reasoner: null } };
  if (!complete(a)) return { a: summary(a), b: { ...b, reason: 'Pominięto wariant B, ponieważ wariant A nie został ukończony.' } };
  const extract = await run(reader, readInstruction, source);
  b.extract = extract.text;
  b.cost_usd = extract.cost_usd;
  b.usage.reader = extract.usage;
  if (!complete(extract)) return { a: summary(a), b: { ...b, decision: extract.decision, reason: extract.reason, stop_reason: extract.stop_reason } };
  const answer = await run(reasoner, reasonInstruction, `Wyciąg faktów:\n${extract.text}`);
  return { a: summary(a), b: { ...b, ...summary(answer), cost_usd: b.cost_usd + answer.cost_usd,
    usage: { reader: extract.usage, reasoner: answer.usage } } };
}

module.exports = { readApiPolicy, billingPeriod, calculateCost, recordUsage, decideStart, createMemoryStore,
  readCanonFile, runOnce, compareReadThenReason, ToolValidationError };
